package day567;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Animal {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

class Dog extends Animal {
	public Dog() {

	}

	public Dog(String name) {
		this.setName(name);
	}

}

class Cat extends Animal {
	public Cat() {

	}

	public Cat(String name) {
		this.setName(name);
	}

}

public class TestAnimal {

	public static void main(String args[]) {
		Animal[] as = new Animal[] { new Dog("Pluto"), new Cat("Tom"), new Dog("Snoopy"), new Cat("Garfield") };
		Dog[] dogs = getAllDog(as);
		for (int i = 0; i < dogs.length; i++) {
			System.out.println(dogs[i].getName());
		}
	}

	public static Dog[] getAllDog(Animal[] as){
			Dog[] ds=new Dog[10];
			int count=0;
			for(int i=0;i<as.length;i++){
				if(as[i] instanceof Dog){
					ds[count++]=(Dog) as[i];
				}
			}
			ds=Arrays.copyOf(ds, count);
			return ds;
		}

}
