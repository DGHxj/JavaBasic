/**
 * @Package: day567 
 * @author: Join Snow   
 * @date: 2018��8��12�� ����12:30:22
 */
package day567;

import java.util.Scanner;

/**
 * @author Join Snow
 *
 */
public class T0502 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		printYZ(i);
	}
	public static void printYZ(int n){
		for(int i=1;i<n;i++){
			if(n%i==0){
				System.out.print(i+" ");
			}
		}
	}
	
}
