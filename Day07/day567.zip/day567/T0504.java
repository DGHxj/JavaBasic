/**
 * @Package: day567 
 * @author: Join Snow   
 * @date: 2018��8��12�� ����12:39:40
 */
package day567;

import java.util.Scanner;

/**
 * @author Join Snow
 *
 */
public class T0504 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		num(i);
	}
	
	public static void num(int n){
		int count=0;
		while(n!=0){
			n/=10;
			count++;
		}
		System.out.println(count);
	}
}
