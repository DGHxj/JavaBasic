/**
 * @Package: day567 
 * @author: Join Snow   
 * @date: 2018��8��12�� ����1:21:33
 */
package day567;

/**
 * @author Join Snow
 *
 */
public class T0508 {
	public static void main(String[] args) {
		for(int i=1;i<3000;i++){
			int a=fj(i);
			if(fj(a)==i&&i<a){
				System.out.println(i+" "+a);
			}
		}
	}
	
	public static int fj(int n){
		int sum=0;
		for(int i=1;i<n;i++){
			if(n%i==0){
				sum+=i;
			}
		}
		return sum;
	}
}
