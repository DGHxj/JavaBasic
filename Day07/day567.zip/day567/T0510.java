/**
 * @Package: day567 
 * @author: Join Snow   
 * @date: 2018��8��12�� ����1:49:33
 */
package day567;

import java.util.Scanner;

/**
 * @author Join Snow
 *
 */
public class T0510 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(f(n));
	}
	
	public static int f(int n){
		if(n==1) return 1;
		return n+f(n-1);
	}
}
