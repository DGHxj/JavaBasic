package day567;

import java.text.DecimalFormat;

public class T0601 {

	public static void main(String[] args) {
		Complex c=new Complex(1.5,-3);
		Complex c1=new Complex(2.3,2.4);
		Complex c2=new Complex(3,5);
		Complex c3=new Complex(4,6);
		System.out.println(c.add(c1).toString());
		System.out.println(c.sub(c1).toString());
		System.out.println(c2.multi(c3).toString());
	}

}

class Complex {
	double real;
	double im;
	
	
	
	public Complex(double real, double im) {
		super();
		this.real = real;
		this.im = im;
	}

	public Complex add(Complex c) {
		this.real+=c.real;
		this.im+=c.im;
		return this;
		
	}

	public Complex add(double real) {
		this.real+=real;
		return this;
	}
	public Complex sub(Complex c) {
		this.real-=c.real;
		this.im-=c.im;
		return this;
		
	}

	public Complex sub(double real) {
		this.real+=real;
		return this;
	}
	public Complex multi(Complex c) {
		double f=this.real;
		this.real=(this.real*c.real)-(this.im*c.im);
		this.im=(f*c.im)+(this.im*c.real);
		
		return this;
		
	}


	@Override
	public String toString() {
		DecimalFormat df = new DecimalFormat( "0.0"); 
		if(im>0){
			return real  +"+"+ df.format(im)+"i";
		}
		return real  +""+ df.format(im)+"i";
	}
	
	
}