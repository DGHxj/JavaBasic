/**
 * @Package: day567 
 * @author: Join Snow   
 * @date: 2018��8��12�� ����12:53:44
 */
package day567;

import java.util.Scanner;

/**
 * @author Join Snow
 *
 */
public class T0506 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		int j=sc.nextInt();
		int k=sc.nextInt();
		int l=sc.nextInt();
		
		jl(i,j,k,l);
	}

	private static void jl(int i, int j, int k, int l) {
		
		System.out.println(Math.sqrt((Math.abs(i-k))*(Math.abs(i-k))+(Math.abs(j-l))*(Math.abs(j-l))));
		return;
	}
}
