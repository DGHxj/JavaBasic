/**
 * @Package: day567 
 * @author: Join Snow   
 * @date: 2018��8��12�� ����1:52:52
 */
package day567;

import java.util.Scanner;

/**
 * @author Join Snow
 *
 */
public class T0511 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(faibo(n));
	}

	private static int faibo(int n) {
		if(n==1||n==2){
			return 1;
		}
		return faibo(n-1)+faibo(n-2);
	}
}
