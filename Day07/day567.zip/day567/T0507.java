package day567;


public class T0507 {
	public static void main(String args[]) {

		qi();
	}

	public static void qi() {
		int a, b;
		for (a = 100; a < 1000; a++) {
			for (b = 100; b < 1000; b++) {
				if (isFlag(a) && isFlag(b)) {
					if (isFlag((a / 100) * 10 + (b / 100)) && isFlag(((a % 100 / 10 * 10) + b % 100 / 10)) && isFlag(a %10 *10+ b % 10)) {
						System.out.println(a + " " + b);
					}
				}
			}
		}
	}

	public static boolean isFlag(int n) {

		int m = (int) Math.sqrt(n);
		if (m * m == n)
			return true;
		return false;

	}
}