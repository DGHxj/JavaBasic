package homework.day03;

public class Problem11 {
	public static void main(String[] args) {
		int i=3;
		while(i<100){
			if(i%5!=0){
				System.out.println(i);
			}
			
			i+=3;
		}
	}
}
